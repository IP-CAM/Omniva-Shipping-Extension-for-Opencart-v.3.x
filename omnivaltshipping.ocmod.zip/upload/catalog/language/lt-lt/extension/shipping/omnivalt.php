<?php
// Text
$_['text_title']                               = 'Omniva';
$_['text_courier']                             = 'Omniva kurjeris';
$_['text_parcel_terminal']                     = 'Omniva paštomatas';
$_['text_select_terminal']                     = 'Pasirinkite paštomatą';

//map
$_['text_omniva_map_head']         = 'Omniva paštomatai';
$_['text_omniva_terminal_address'] = 'Paštomatų adresai';
$_['text_select_omn_terminal']     = 'Pasirinkti pašomatą';
$_['text_omniva_search']           = 'Įveskite pašto kodą / adresą';
$_['text_omniva_show_map']         = 'Žiūrėti žemėlapyje';
$_['text_omniva_show_more']        = 'Rodyti daugiau';
$_['text_omniva_not_found']        = 'Vieta nerasta';
$_['text_omniva_back_to_list']     = 'Grįžti į sąrašą';
