<?php
// Text
$_['text_title']                               = 'Omniva lt';
$_['text_courier']                             = 'Omniva courier';
$_['text_parcel_terminal']                     = 'Omniva parcel terminal';
$_['text_select_terminal']                     = 'Select parcel terminal';

$_['text_omniva_map_head']          = 'Omniva terminals';
$_['text_omniva_terminal_address']  = 'Terminals addressess';
$_['text_select_omn_terminal']      = 'Choose terminal';
$_['text_omniva_search']            = 'Enter postcode/address';
$_['text_omniva_show_map']          = 'Show in map';
$_['text_omniva_show_more']         = 'Show more';
$_['text_omniva_not_found']         = 'Place not found';
$_['text_omniva_back_to_list']      = 'Back to list';
