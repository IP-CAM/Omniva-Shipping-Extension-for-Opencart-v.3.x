<?php
// Text
$_['text_title']                               = 'Omniva';
$_['text_courier']                             = 'Omniva kurjerpakalpojums';
$_['text_parcel_terminal']                     = 'Omniva pakomāts';
$_['text_select_terminal']                     = 'Izvēlieties paku termināli';

$_['text_omniva_map_head']          = 'Omniva Pakomāts';
$_['text_omniva_terminal_address']  = 'Pakomāts adrese';
$_['text_select_omn_terminal']      = 'Izvēlieties';
$_['text_omniva_search']            = 'Ievadiet pasta indeksu/adresi';
$_['text_omniva_show_map']          = 'Apskatīt novietojumu';
$_['text_omniva_show_more']         = 'Parādīt vairāk';
$_['text_omniva_not_found']         = 'Vieta nav atrasta';
$_['text_omniva_back_to_list']      = 'Atpakaļ';
