<?php
$_['heading_title'] = 'Omnivalt Events';